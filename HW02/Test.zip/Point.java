/* Khalid Elhousieny 
 * HW02
 * CS 211 James Livingston 
 * April 24th 2021
 * 
 * This class will be used as the point class for exercises 19 and 20 for HW02
 * It will implement the comparable interface and add a comparable method 
 * to compare Y coordinates and return a value based on if the value is greater than or less than another Y coordinate
 * 
 * A Point object represents a pair of (x, y) coordinates. 
 * Class invariant: x >= 0 && y >= 0. (Quadrant I only) 
 */

public class Point implements Comparable<Point> {
    private int x;
    private int y;

    // Constructs a new point at the given (x, y) location.
    // pre: x >= 0 && y >= 0
    public Point(int x, int y) {
	if (x < 0 || y < 0) {
	    throw new IllegalArgumentException();
	}
	this.x = x;
	this.y = y;
    }

    // Constructs a new point at the origin, (0, 0).
    public Point() {
	this(0, 0); // calls Point(int, int) constructor }
    }

    // Returns the distance between this Point and (0, 0).
    public double distanceFromOrigin() {
	return Math.sqrt(x * x + y * y);
    }

    // Returns whether o refers to a point with the same (x, y)
    // coordinates as this point. Robust version.
    public boolean equals(Object o) {
	if (o instanceof Point) {
	    Point other = (Point) o;
	    return this.x == other.getX() && this.y == other.getY();
	} else { // not a Point object
	    return false;
	}
    }

    // Returns the x-coordinate of this point.
    public int getX() {
	return this.x;
    }

    // Returns the y-coordinate of this point.
    public int getY() {
	return this.y;
    }

    // Returns a String representation of this point.
    public String toString() {
	return "(" + this.x + ", " + this.y + ")";
    }

    // Returns a new point, shifted from this one by dx and dy.
    // pre: x + dx >= 0 && y + dy >= 0
    public Point translate(int dx, int dy) {
	return new Point(this.x + dx, this.y + dy);
    }

    /* This comparable method will first test to see if the value of the entered
     * point is greater than or less than the second point
     * they have the same value then it will test for the X values of each point
     * and return the correct symbol and value
     */
    public int compareTo(Point other) {
	if (this.y > other.y) { // If the y of the first point is greater than the Y it is comparing to 
	    return 1; // Then it will return 1
	}
	else if (this.y < other.y) { // If the y of the first point is less than the Y it is comparing to 
	    return -1; // Then it return -1
	}
	else { // If both Y values are the same then the X values will be compared to one another
	    if (this.x > other.x) { // If the X value of the first point is greater than the X it is comparing to 
		return 1; // Then it will return 1
	    } else if (this.x < other.x) { // If the X value of the first point is less than the X it is comparing to 
		return -1; // Then it will return - 1
	    }
	}
	return 0; // In both cases if the values are the same it will jump here and return 0
    }

}
